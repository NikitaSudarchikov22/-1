import tkinter as tk
from tkinter import messagebox
import json
import os

DATA_FILE = "water_tracker_data.json"

def load_data():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    return {"day": 0, "week": 0, "month": 0}

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)

water_data = load_data()

def update_water(period, amount):
    try:
        amount = int(amount)
        if amount < 0:
            raise ValueError("Отрицательное значение")
        water_data[period] += amount
        update_display()
        save_data(water_data)
    except ValueError:
        messagebox.showerror("Ошибка", "Введите корректное положительное число")

def update_display():
    day_label.config(text=f"Выпито за день: {water_data['day']} мл")
    week_label.config(text=f"Выпито за неделю: {water_data['week']} мл")
    month_label.config(text=f"Выпито за месяц: {water_data['month']} мл")

def reset_data():
    for key in water_data:
        water_data[key] = 0
    update_display()
    save_data(water_data)

def open_main_app():
    login_window.destroy()

    root = tk.Tk()
    root.title("Трекер выпитой воды")

    global day_label, week_label, month_label
    day_label = tk.Label(root, text=f"Выпито за день: {water_data['day']} мл", font=("Arial", 12))
    day_label.pack(pady=5)

    week_label = tk.Label(root, text=f"Выпито за неделю: {water_data['week']} мл", font=("Arial", 12))
    week_label.pack(pady=5)

    month_label = tk.Label(root, text=f"Выпито за месяц: {water_data['month']} мл", font=("Arial", 12))
    month_label.pack(pady=5)

    entry_label = tk.Label(root, text="Введите количество воды (мл):", font=("Arial", 10))
    entry_label.pack(pady=5)

    global entry
    entry = tk.Entry(root, font=("Arial", 10))
    entry.pack(pady=5)

    day_button = tk.Button(root, text="Добавить за день", command=lambda: update_water("day", entry.get()))
    day_button.pack(pady=5)

    week_button = tk.Button(root, text="Добавить за неделю", command=lambda: update_water("week", entry.get()))
    week_button.pack(pady=5)

    month_button = tk.Button(root, text="Добавить за месяц", command=lambda: update_water("month", entry.get()))
    month_button.pack(pady=5)

    reset_button = tk.Button(root, text="Сбросить данные", command=reset_data, bg="red", fg="white")
    reset_button.pack(pady=10)

    root.mainloop()

login_window = tk.Tk()
login_window.title("Авторизация")

username_label = tk.Label(login_window, text="Имя пользователя:", font=("Arial", 10))
username_label.pack(pady=5)
username_entry = tk.Entry(login_window, font=("Arial", 10))
username_entry.pack(pady=5)

password_label = tk.Label(login_window, text="Пароль:", font=("Arial", 10))
password_label.pack(pady=5)
password_entry = tk.Entry(login_window, font=("Arial", 10), show="*")
password_entry.pack(pady=5)

login_button = tk.Button(
    login_window,
    text="Войти",
    command=open_main_app,
    bg="green",
    fg="white"
)
login_button.pack(pady=10)

login_window.mainloop()